This python file is used to generate file config (.items and .sitemap file) and to simulate data sensor for OpenHAB IoT platform.
