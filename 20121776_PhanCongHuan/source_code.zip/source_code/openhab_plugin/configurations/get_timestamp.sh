#!/bin/bash

MESSAGE=$1
ITEM_NAME=$2
platform_detail=()
tmp=$(sed -e '$!d' /etc/hosts | tr '\t ' ';')
IFS=';' read -ra ADDR <<< "$tmp"
platform_ip=${ADDR[0]}
platform_host=${ADDR[1]}
timestamp=$(date +%s.%M)
#wget "http://just-the-time.appspot.com/?f=%s.%f" -q -O /openhab/configurations/timestamp
#timestamp=$(cat /openhab/configurations/timestamp)
endpoint=${platform_ip}/demo/${ITEM_NAME}
platform_id=${platform_host}:${platform_ip}
resource="{\"Endpoint\":\"${endpoint}\",\"State\":\"active\", \"PlatformListener\":\"${platform_id}\", \"Regex\": \"(.*)\"}"
tmp="{\"Resource\":${resource},\"Timestamp\":\"${timestamp}\",\"Sensor\":${MESSAGE}}"
echo $tmp
