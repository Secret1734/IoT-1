#!/bin/bash
# register with platform manager
platform_detail=$(sed -e '$!d' /etc/hosts | tr '\t ' ',')
wget "http://${CO_ORDINATOR_DOMAIN}/platform/register?platform=${platform_location}"
# get sensor id
wget "http://${CO_ORDINATOR_DOMAIN}/platform/assignment?resource=sensor_id&platform=${platform_location}" -O ${PWD}/sensor_id.cfg
sensor_id=`cat sensor_id.cfg`
# get sensor config
wget "http://${CO_ORDINATOR_DOMAIN}/platform/assignment?resource=config_file&sensor_id=${sensor_id}&platform=${platform_location}" -O /openhab/configurations/items/demo.items
# register with platform assigner
wget "http://${CO_ORDINATOR_DOMAIN}/platform/assignment?action=register_succeed&platform=${platform_location}&sensor_id=${sensor_id}"
##############
wget "http://${CO_ORDINATOR_DOMAIN}/sensor/define?resource=defined_file" -O /openhab/configurations/items/demo_2.items
platform_location=$(sed -e '$!d' /etc/hosts | tr '\t ' '-')
wget http://${CO_ORDINATOR_DOMAIN}/sensor/define?resource=sensor_id -O ${PWD}/sensor_id.cfg
sensor_id=`cat sensor_id.cfg`
wget "http://${CO_ORDINATOR_DOMAIN}/platform/status?platform=${platform_location}&sensor_id=${sensor_id}"