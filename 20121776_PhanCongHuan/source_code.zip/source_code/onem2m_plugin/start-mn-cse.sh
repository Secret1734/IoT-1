#!/bin/bash

cd './org.eclipse.om2m/org.eclipse.om2m.site.mn-cse/target/products/mn-cse/linux/gtk/x86_64'

bash ./start.sh

