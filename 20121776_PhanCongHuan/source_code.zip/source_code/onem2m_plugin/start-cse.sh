#!/bin/bash

cd './org.eclipse.om2m/org.eclipse.om2m.site.in-cse/target/products/in-cse/linux/gtk/x86_64'

bash ./start.sh

