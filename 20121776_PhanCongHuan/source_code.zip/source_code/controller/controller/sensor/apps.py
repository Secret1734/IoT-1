from django.apps import AppConfig


class SensorConfig(AppConfig):
    name = 'sensor'
