from django.apps import AppConfig


class IotPlatformConfig(AppConfig):
    name = 'iot_platform'
