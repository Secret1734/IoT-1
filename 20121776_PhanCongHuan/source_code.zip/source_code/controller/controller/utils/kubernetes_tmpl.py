OPENHAB_CONFIG = '''
# This is the default configuration file, which comes with every openHAB distribution.
# You should do a copy of it with the name 'openhab.cfg' and configure your personal
# settings in there. This way you can be sure that they are not overwritten, if you
# update openHAB one day.


#######################################################################################
#####                        General configurations                               #####
#######################################################################################

# Configuration folders (must exist as a subdirectory of "configurations"; the value
# tells the number of seconds for the next scan of the directory for changes. A
# value of -1 deactivates the scan).
# A comma separated list can follow after the refresh value. This list defines a filter
# for valid file extensions for the models.
folder:items=10,items
folder:sitemaps=10,sitemap
folder:rules=10,rules
folder:scripts=10,script
folder:persistence=10,persist

# configures the security options. The following values are valid:
# ON = security is switched on generally
# OFF = security is switched off generally
# EXTERNAL = security is switched on for external requests
#            (e.g. originating from the Internet) only
# (optional, defaults to 'OFF')
#security:option=

# the Netmask to define a range of internal IP-Addresses which doesn't require
# authorization (optional, defaults to '192.168.1.0/24')
#security:netmask=

# The name of the default persistence service to use
persistence:default=rrd4j

# The refresh interval for the main configuration file. A value of '-1'
# deactivates the scan (optional, defaults to '-1' hence scanning is deactivated)
#mainconfig:refresh=

# Bind service discovery to specific hostname or IP address
#servicediscovery:bind_address=127.0.0.1

################################## Chart Servlet ######################################
#
# This section defines the configuration for the chart servlet.
chart:provider=default

#
# Set the default height of a chart if the client doesn't provide this in the request
# defaults to 240
#chart:defaultHeight=240

#
# Set the default width of a chart if the client doesn't provide this in the request
# defaults to 480
#chart:defaultWidth=480

#
# Set a scale factor. This is used if the client sets the size in the request.
# defaults to 1 (ie no scaling)
#chart:scale=1


#######################################################################################
#####                       Action configurations                                 #####
#######################################################################################

######################## Mail Action configuration ####################################
#
# The SMTP server hostname, e.g. "smtp.gmail.com"
#mail:hostname=

# the SMTP port to use (optional, defaults to 25 (resp. 587 for TLS))
#mail:port=

# the username and password if the SMTP server requires authentication
#mail:username=
#mail:password=

# The email address to use for sending mails
#mail:from=

# set to "true", if TLS should be used for the connection
# (optional, defaults to false)
#mail:tls=

# set to "true", if POP before SMTP (another authentication mechanism)
# should be enabled. Username and Password are taken from the above
# configuration (optional, default to false)
#mail:popbeforesmtp=

# Character set used to encode message body
# (optional, if not provided platform default is used)
#mail:charset=

########################## XMPP Action configuration ##################################
#

# The username of the XMPP account used by openHAB
# Most services will require that you use only the localpart of the accounts JID.
# For example if your accounts JID is myuser@example.org, then only configure 'myuser'.
#xmpp:username=myuser

# The password of the XMPP account used by openHAB
#xmpp:password=mypassword

# The XMPP service to use, e.g. "jabber.de"
# A list of public XMPP services can be found at https://xmpp.net/directory.php
#xmpp:servername=example.org

# The Security mode used for the XMPP connection. Can be either 'required'
# or 'disabled'. Defaults to 'disabled', which means that TLS will not be used.
# Warning: If you change this to non-disabled, then you must make sure that your
# TLS server certificate can be validated, otherwhise the connection will fail.
#xmpp:securitymode=disabled

# The TLS Pin used to verify the XMPP service's certificate. Set this in case openhab's
# default SSLContext is unable to verfiy it (e.g. because the XMPP service uses a self-signed
# certificate). The PIN value is bascially the hash of the certificate in hex.
# You have to set 'xmpp:securitymode' to 'required' to enable TLS for XMPP connections.
# For information on how to generate the PIN visit https://github.com/Flowdalic/java-pinning
#xmpp:tlspin=CERTSHA256:83:F9:17:1E:06:A3:13:11:88:89:F7:D7:93:02:BD:1B:7A:20:42:EE:0C:FD:02:9A:BF:8D:D0:6F:FA:6C:D9:D3

# The XMPP Proxyserver to use, e.g. "gmail.com"
#xmpp:proxy=

# the server port to use (optional, defaults to 5222)
#xmpp:port=

# a comma separated list of users that are allowed to use the XMPP console
#xmpp:consoleusers=

# the multi user chat to join, e.g. openhab@chat.example.com
#xmpp:chatroom=

# the nickname used in the multi user chat (optional, defaults to openhab-bot)
#xmpp:chatnickname=

# the password required to join the multi user chat
#xmpp:chatpassword=

########################## Prowl Action configuration #################################
#
# the apikey for authentication (generated on the Prowl website)
#prowl:apikey=

# the default priority of a Prowl notifications (optional, defaults to '0')
#prowl:defaultpriority=

# the url of the Prowl public api
# (optional, defaults to 'https://prowl.weks.net/publicapi/')
#prowl:url=

#################### Pushover Action configuration #####################
#
# The timeout for the communication with the Pushover service (optional, defaults
# to 10000 milliseconds)
#pushover:defaultTimeout=

# You need to provide a Pushover API token to send to devices. If not here, than during
# the action call itself.
#pushover:defaultToken=

# You need to provide a Pushover User Key to send to devices. If not here, than during
# the action call itself.
#pushover:defaultUser=

# Name of the sending application (optional). Defaults to 'openHAB'.
#pushover:defaultTitle=openHAB

# The priority to use for messages if not specified otherwise. Can range from
# -2 (lowest) to 2 (highest)
#pushover:defaultPriority=

# Url to attach to the message if not specified in the command (optional). Can be left empty.
#pushover:defaultUrl=

# Url Title to attach to the message if not specified in the command (optional). Can be left empty.
#pushover:defaultUrlTitle=

# When priority is high priority (2), how often in seconds should messages be resent. Defaults to 300 seconds.
#pushover:defaultRetry=

# When priority is high priority (2), how long to continue resending messages until acknowledged. Defaults to 3600 seconds.
#pushover:defaultExpire=

########################### Twitter Action configuration ##############################
#
# The ConsumerKey, ConsumerSecret combination (optional, defaults to official Twitter-App
# Key-Secret-Combination)
#twitter:key=
#twitter:secret=

# Flag to enable/disable the Twitter client (optional, defaults to 'false')
#twitter:enabled=

#################### Notify my Android (NMA) Action configuration #####################
#
# The timeout for the communication with the NMA service (optional, defaults
# to 10000 milliseconds)
#nma:timeout=

# If you have a developerKey from NMA you can set it here, but this completely optional
#nma:developerKey=

# The default api key to send messages to. Api keys can be created in your accounts dashboard.
#nma:apiKey=

# The application name which NMA will show (optional, defaults to 'openHAB').
#nma:appName=

# The priority to use for messages if not specified otherwise. Can range from
# -2 (lowest) to 2 (highest)
#nma:defaultPriority=

# The URL to attach to NMA messages by default  if not specified otherwise. Can be left empty.
#nma:defaultUrl=

####################### OpenWebIf Action configuration ########################
#
#openwebif:receiver.<name>.host=
#openwebif:receiver.<name>.port=
#openwebif:receiver.<name>.user=
#openwebif:receiver.<name>.password=
#openwebif:receiver.<name>.https=

#######################################################################################
#####                   I/O component configurations                              #####
#######################################################################################

########################## Google Calendar configuration ##############################
#
# the username and password for Google Calendar Account
#gcal:username=
#gcal:password=

# the url of the calendar feed
#gcal:url=

# the filter criteria for full text query (optional)
#gcal:filter=

# refresh interval in milliseconds (optional, defaults to 900000 [15 minutes])
#gcal:refresh=

############################# Dropbox configuration ###################################
#
# Operates the Synchronizer in fake mode which avoids up- or downloading files to and from Dropbox.
# This is meant as testMode for the filter settings (optional, defaults to false)
#dropbox:fakemode=

# the up- and download interval as Cron-Expression. See the Quartz-Tutorial
# http://quartz-scheduler.org/documentation/quartz-2.x/tutorials/tutorial-lesson-06
# for more information on how to use them best (optional, defaults to '0 0/5 * * * ?'
# which means every 5 minutes)
#dropbox:uploadInterval=
#dropbox:downloadInterval=

# the AppKey, AppSecret combination (optional, defaults to official Dropbox-App
# Key-Secret-Combination)
#dropbox:appkey=
#dropbox:appsecret=

# defines the mode how files are synchronized with dropbox. Valid SyncModes are
# 'DROPBOX_TO_LOCAL', 'LOCAL_TO_DROPBOX' and 'BIDIRECTIONAL' (optional, defaults
# to 'LOCAL_TO_DROPBOX')
#dropbox:syncmode=

# the base directory to synchronize with openHAB, configure 'filter' to select
# files (optional, defaults to '.')
#dropbox:contentdir=

# defines a comma separated list of regular expressions which matches the
# filenames to upload to Dropbox (optional, defaults to '/configurations/.*,
# /logs/.*, /etc/.*')
#dropbox:uploadfilter=

# defines a comma separated list of regular expressions which matches the
# filenames to download from Dropbox (optional, defaults to '/configurations/.*')
#dropbox:downloadfilter=

############################# MaryTTS configuration ###################################
#
# the default voice used by the MaryTTS engine. Available voices are: bits1-hsmm
# (german, female), bits3-hsmm (german, male), cmu-slt-hsmm (english, male) (optional,
# defaults to the systems' default voice or the first available voice)
#marytts:voice=

###################### Speech-Dispatcher TTS configuration ############################
#
# Hostname or ip of the first Speech Dispatcher device to control
# speechdispatcher:<SDId1>.host=
# Port of the Speech Dispatcher to control (optional, defaults to 6560)
# speechdispatcher:<SDId1>.port=6560

###################### GoogleTTS configuration ############################
#
# The language to be used by the GoogleTTS engine (optional, default: 'en').
# Language must be supported for audio output by https://translate.google.com.
# googletts:language=en
# Sentence delimiters used to split text into sentences (optional, default: !.?:;)
# googletts:sentenceDelimiters=
# Google Translate URL to be used for converting text to speech (optional,
# defaults to http://translate.google.com/translate_tts?tl=%s&q=%s&client=t).
# googletts:translateUrl=

#######################################################################################
#####                      Persistence configurations                             #####
#######################################################################################

########################### RRD4J Persistence Service #################################
#
# please note that currently the first archive in each RRD defines the consolidation
# function (e.g. AVERAGE) used by OpenHAB, thus only one consolidation function is
# fully supported
#
# default_numeric and default_other are internally defined defnames and are used as
# defaults when no other defname applies

#rrd4j:<defname>.def=[ABSOLUTE|COUNTER|DERIVE|GAUGE],<heartbeat>,[<min>|U],[<max>|U],<step>
#rrd4j:<defname>.archives=[AVERAGE|MIN|MAX|LAST|FIRST|TOTAL],<xff>,<steps>,<rows>
#rrd4j:<defname>.items=<list of items for this defname>

######################## Open.Sen.se Persistence Service ##############################
#
# the url of the Open.Sen.se public api (optional, defaults to
# 'http://api.sen.se/events/?sense_key=')
#sense:url=

# the Open.Sen.se API-Key for authentication (generated on the Open.Sen.se website)
#sense:apikey=

######################### Logging Persistence Service #################################
#
# the logback encoder pattern to use to write log entries
# see http://logback.qos.ch/manual/layouts.html#ClassicPatternLayout for all options
# the item name is available as the "logger" name, the state as the "msg"
logging:pattern=%date{ISO8601} - %-25logger: %msg%n

########################### Db4o Persistence Service ##################################
#
# the backup interval as Cron-Expression (optional, defaults to '0 0 1 * * ?'
# which means every morning at 1 o'clock)
#db4o:backupinterval=

# the commit interval in seconds (optional, default to '5')
#db4o:commitinterval=

# the amount of backup files allowed in DB_FOLDER_NAME (optional, defaults
# to '7')
#db4o:maxbackups=

############################ SQL Persistence Service ##################################
# the database url like 'jdbc:mysql://<host>:<port>/<database>' (without quotes)
#mysql:url=

# the database user
#mysql:user=

# the database password
#mysql:password=

# the reconnection counter
#mysql:reconnectCnt=

# the connection timeout (in seconds)
#mysql:waitTimeout=

############################ Cosm Persistence Service #################################
#
# the url of the Cosm feed (optional, defaults to 'http://api.cosm.com/v2/feeds/')
#cosm:url=

# the Cosm API-Key for authentication (generated on the Cosm website)
#cosm:apikey=

############################ GCal Persistence Service #################################
#
# the username and password for Google Calendar Account
#gcal-persistence:username=
#gcal-persistence:password=

# the url of the calendar feed
#gcal-persistence:url=

# the offset (in days) new calendar entries will be created in future (optional,
# defaults to 14)
#gcal-persistence:offset=

# the base script which is written to the newly created Calendar-Events by
# the GCal-based presence simulation. It must contain two format markers '%s'.
# The first marker represents the Item to send the command to and the second
# represents the State (optional, defaults to
# '> if (PresenceSimulation.state == ON) sendCommand(%s,%s)')
#gcal-persistence:executescript=

################################# MQTT Persistence #########################################
#
# Name of the broker as defined in the section MQTT Transport
# mqtt-persistence:broker=

# The MQTT topic to which the persistence messages should be sent.
# mqtt-persistence:topic=

# A string representing the persistence message content.
# mqtt-persistence:message=

############################ MongoDB Persistence Service ##################################
#
# the database URL, e.g. mongodb://127.0.0.1:27017
#mongodb:url=mongodb://127.0.0.1:27017

# the database name
#mongodb:database=openhab

# the collection name
#mongodb:collection=openhab


############################ InfluxDB 0.8 Persistence Service #############################
#
# The database URL, e.g. http://127.0.0.1:8086 or https://127.0.0.1:8084 .
# Defaults to: http://127.0.0.1:8086
# influxdb08:url=http(s)://<host>:<port>

# The name of the database user, e.g. openhab.
# Defaults to: openhab
# influxdb08:user=<user>

# The password of the database user.
# influxdb08:password=

# The name of the database, e.g. openhab.
# Defaults to: openhab
# influxdb08:db=<database>

############################ InfluxDB Persistence Service #############################
#
# The database URL, e.g. http://127.0.0.1:8086 or https://127.0.0.1:8084 .
# Defaults to: http://127.0.0.1:8086
# influxdb:url=http(s)://<host>:<port>

# The name of the database user, e.g. openhab.
# Defaults to: openhab
# influxdb:user=<user>

# The password of the database user.
# influxdb:password=

# The name of the database, e.g. openhab.
# Defaults to: openhab
# influxdb:db=<database>

############################ JPA Persistence Service ##################################
#
# The JPA bundle includes only the embedded derby driver.
# If you want to use a different database, like PostgreSQL, just
# drop the PostgreSQL driver jhar into the 'addons' folder of openhab.
#

# connection string url
#jpa:url=jdbc:postgresql://<host>:5432/<databasename>
#jpa:jdbc:mysql://<host>:3306/<databasename>
#jpa:url=jdbc:derby://<host>:1527/<databasename>;create=true
#jpa:url=jdbc:derby:<databasename>;create=true

# driver class name
#jpa:driver=org.postgresql.Driver                   #
#jpa:driver=com.mysql.jdbc.Driver                   #
#jpa:driver=org.apache.derby.jdbc.ClientDriver      #
#jpa:driver=org.apache.derby.jdbc.EmbeddedDriver    # (included)

# username
#jpa:user=

# password
#jpa:password=

# synchronize mappings
# !!! Attention: only change those if you know what you're doing. You can wipe your table or database.
# default is: "buildSchema(schemaAction='add')"
#jpa:syncmappings=

########################### MapDB Persistence Service ##################################
# the commit interval in seconds (optional, default to '5')
#mapdb:commitinterval=5

# issue a commit even if the state did not change (optional, defaults to 'false')
#mapdb:commitsamestate=false

########################### calDAV Persistence Service ##################################
# Every item which is stored, results in an event entry in the defined calendar
#
# Calendar ID, which is defined in calDAV IO section
#caldav-persistence:calendarId=<calendar id>
#
# Default duration for an calendar entry is 5 minutes
#caldav-persistence:duration=
#
# For Switch-, Contact- and Percent-Items it is possible to create events,
# with the correct duration for e. g. Switch ON to Switch OFF, otherwise every item change
# will result in a new single calendar entry.
#caldav-persistence:singleEvents=true

#######################################################################################
#####                       Transport configurations                              #####
#######################################################################################

################################# MQTT Transport ######################################
#
# Define your MQTT broker connections here for use in the MQTT Binding or MQTT
# Persistence bundles. Replace <broker> with a id you choose.
#

# URL to the MQTT broker, e.g. tcp://localhost:1883 or ssl://localhost:8883
#mqtt:<broker>.url=tcp://<host>:1883

mqtt:mqttIn.url=tcp://mqtt-service:1883

mqtt:mqttOut.url=tcp://188.166.238.158:30146

# Optional. Client id (max 23 chars) to use when connecting to the broker.
# If not provided a default one is generated.
#mqtt:<broker>.clientId=<clientId>
mqtt:mqttIn.clientId=/mqttIn.clientId/
mqtt:mqttOut.clientId=/mqttIn.clientId/

# Optional. User id to authenticate with the broker.
# mqtt:<broker>.user=<user>

# Optional. Password to authenticate with the broker.
#mqtt:<broker>.pwd=<password>

# Optional. Set the quality of service level for sending messages to this broker.
# Possible values are 0 (Deliver at most once),1 (Deliver at least once) or 2
# (Deliver exactly once). Defaults to 0.
#mqtt:<broker>.qos=<qos>

# Optional. True or false. Defines if the broker should retain the messages sent to
# it. Defaults to false.
#mqtt:<broker>.retain=<retain>

# Optional. True or false. Defines if messages are published asynchronously or
# synchronously. Defaults to true.
#mqtt:<broker>.async=<async>

# Optional. Defines the last will and testament that is sent when this client goes offline
# Format: topic:message:qos:retained <br/>
#mqtt:<broker>.lwt=<last will definition>



#######################################################################################
#####                        Binding configurations                               #####
#######################################################################################

################################ KNX Binding ##########################################
#
# KNX gateway IP address
# (optional, if serialPort or connection type 'ROUTER' is specified)
#knx:ip=

# Local KNX Binding bus address.
# Use it, when two or more openHAB Instances are connected to the same KNX bus.
# (optional, defaults to 0.0.0)
#knx:busaddr=

# Ignore local KNX Events, prevents internal events coming from
# 'openHAB event bus' a second time to be sent back to the 'openHAB event bus'.
# Note: To send back events second time is a Bug, but for backward compatibility, the behavior is not changed.
# For new installations, its recommend to set "knx:ignorelocalevents=true"
# (optional, defaults to false)
#knx:ignorelocalevents=

# KNX IP connection type. Could be either TUNNEL or ROUTER (optional, defaults to TUNNEL)
# Note: If you cannot get the ROUTER mode working (even if it claims it is connected),
# use TUNNEL mode instead with setting both the ip of the KNX gateway and the localIp.
#knx:type=

# KNX gateway port (optional, defaults to 3671)
# Note: If you use eibd, setting to 6720
#knx:port=

# Local endpoint to specify the multicast interface, no port is used (optional)
#knx:localIp=

# Serial port of FT1.2 KNX interface (ignored, if ip is specified)
# Valid values are e.g. COM1 for Windows and /dev/ttyS0 or /dev/ttyUSB0 for Linux
#knx:serialPort=

# Pause in milliseconds between two read requests on the KNX bus during
# initialization (optional, defaults to 50)
#knx:pause=

# Timeout in milliseconds to wait for a response from the KNX bus (optional,
# defaults to 10000)
#knx:timeout

# Number of read retries while initialization items from the KNX bus (optional,
# defaults to 3)
#knx:readRetries

# Seconds between connect retries when KNX link has been lost
# 0 means never retry, it will only reconnect on next write or read request
# Note: without periodic retries all events will be lost up to the next read/write
#       request
# (optional, default is 0)
#knx:autoReconnectPeriod=30

### Auto refresh feature
# Number of entries permissible in the item refresher queue.
# (optional, defaults to 10000)
#knx:maxRefreshQueueEntries=

# Number of parallel threads for refreshing items. (optional, defaults to 5)
#knx:numberOfThreads=

# Seconds to wait for an orderly shutdown of the auto refresher's
# ScheduledExecutorService. (optional, defaults to 5)
#knx:scheduledExecutorServiceShutdownTimeoutString=

############################## DSC Alarm Binding #####################################
#
# DSC Alarm interface device type
# Valid values are it100 (default for serial connection) or envisalink (default for tcp connection)
#dscalarm:deviceType=

# DSC Alarm port name for a serial connection.
# Valid values are e.g. COM1 for Windows and /dev/ttyS0 or /dev/ttyUSB0 for Linux.
# Leave undefined if not connecting by serial port.
#dscalarm:serialPort=

# DSC Alarm baud rate for serial connections.
# Valid values are 9600 (default), 19200, 38400, 57600, and 115200.
# Leave undefined if using default.
#dscalarm:baud=

# DSC Alarm IP address for a TCP connection.
# Leave undefined if not connecting by network connection.
#dscalarm:ip=

# DSC Alarm TCP port for a TCP connection.
# Can be EyezOn Envisalink on 4025 (default) or a TCP serial server to IT-100
# Leave undefined if not connecting by network connection.
#dscalarm:tcpPort=

# DSC Alarm password for logging into the EyezOn Envisalink 3/2DS interface.
# Leave undefined if using default.
#dscalarm:password=

# DSC Alarm user code for logging certain DSC Alarm commands.
# Leave undefined if using default.
#dscalarm:usercode=

# DSC Alarm poll period.
# Amount of time elapsed in minutes between poll commands sent to the DSC Alarm.
# Valid values are 1-15 (Default = 1).
# Leave undefined if using default.
#dscalarm:pollPeriod=

############################# Bluetooth Binding #######################################
#
# Bluetooth refresh rate in seconds
# (defines, how often a new device detection scan is performed)
#bluetooth:refresh=20

################################### CalDAV IO Binding ###################################
#
# Used to connect to Cal DAV. All parameters are required.
# Path to the calendar
# caldavio:<calendarId>:url=
#
# Username for the calendar
# caldavio:<calendarId>:username=
#
# Password for the calendar
# caldavio:<calendarId>:password=
#
# Reload interval unit is minutes.
# Defines how often the calendar should be reloaded from server.
# Default is 60 minutes
# caldavio:<calendarId>:reloadInterval=
#
# This defines which events are relevant for execution. Unit is in minutes.
# Default is 1 Day (1440 minutes)
# caldavio:<calendarId>:preloadTime=
#
# A caldav Server is just a webdav Server which list files. Some servers does not use the valid timestamp for modifications.
# If your calendar does not provide correct timestamps you have to set this false.
# Default is true
# caldavio:<calendarId>:lastModifiedFileTimeStampValid=
#
# SSL verification can be disabled, if you don't want to import the server certificate
# into the java keystore. This is just needed for self-signed certificates, where the
# certificate path cannot be verified. Default is false. Do not set to true if no SSL is used.
# caldavio:<calendarId>:disableCertificateVerification=
#
# Timezone for events which does not have a timeZone information.
# Normally this is not required
# caldavio:timeZone=

################################ CalDAV Command Binding ###################################
# see CalDAV IO Binding
# Used to execute commands if events starts or ends with an easy notation in the event description.
# commaseperated (e. g. openhab, anothercalendar)
# caldavCommand:readCalendars=<ids from caldav-io>

############################# CalDAV Personal Binding ################################
# see CalDAV IO Binding
# Used to toggle switch items for presence. Switched to ON if an event in the calendar occurs.
# And back to OFF if the event ends.
# Can also be used to show upcoming or active events
#
# Which calendars should be used to detect presence (comma separated)
# caldavPersonal:usedCalendars=<ids from caldav-io>
#
# If the location of the event is one of this identifiers, the presence will not be changed.
# Can be used for events which are at home or are just reminders. (comma separated, optional)
# caldavPersonal:homeIdentifiers=

############################## OneWire Binding ########################################
#
# OwServer IP address
#onewire:ip=

# OwServer Port (optional, defaults to 4304)
#onewire:port=

# the retry count in case no valid value was returned
# upon read (optional, defaults to 3)
#onewire:retry=

# defines which temperature scale owserver should return temperatures in. Valid
# values are CELSIUS, FAHRENHEIT, KELVIN, RANKINE (optional, defaults to CELSIUS).
#onewire:tempscale=

# only changed values are posted to the event-bus, (optinal, defaults to true - values true or false)
#onewire:post_only_changed_values=

########################### NetworkHealth Binding #####################################
#
# Default timeout in milliseconds if none is specified in binding configuration
# (optional, default to 5000)
#networkhealth:timeout=

# refresh interval in milliseconds (optional, default to 60000)
#networkhealth:refresh=

# Cache the state for n minutes so only changes are posted (optional, defaults to 0 = disabled)
# Example: if period is 60, once per hour the online states are posted to the event bus;
#          changes are always and immediately posted to the event bus.
# The recommended value is 60 minutes.
#networkhealth:cachePeriod=60

############################### HTTP Binding ##########################################
#
# timeout in milliseconds for the http requests (optional, defaults to 5000)
#http:timeout=

# the interval in milliseconds when to find new refresh candidates
# (optional, defaults to 1000)
#http:granularity=

# configuration of the first cache item
# http:<id1>.url=
# http:<id1>.updateInterval=

# configuration of the second cache item
# http:<id2>.url=
# http:<id2>.updateInterval=

############################# Fritz!Box Binding #######################################
#
# Please note: To be able to connect to the monitor port, the "CallMonitor" must be
# activated by dialing "#96*5*" once on a telephone that is connected to the Fritz!Box.

# IP address of Fritz!Box to connect to
#fritzbox:ip=fritz.box

# Only if you would like to use the switches to turn wifi, dect, ... on and off you
# need to configure the password of your Fritz!Box.
#fritzbox:password=

############################### Asterisk Binding ######################################
#
# Please note: The Asterisk Management Interface (AMI) has to be activated in the
# manager.conf file of your Asterisk PBX.

# hostname of the AMI
#asterisk:host=

# the username and password to login to the AMI
#asterisk:username=
#asterisk:password=

###################################### Mochad X10 #####################################
#
# Ip address and port of the Mochad X10 server
#mochadx10:hostIp=
#mochadx10:hostPort=

################################ NTP Binding ##########################################
#
# refresh interval in milliseconds (optional, defaults to 900000 [15 minutes])
#ntp:refresh=

# the hostname of the timeserver
ntp:hostname=ptbtime1.ptb.de

################################ MPD Binding ##########################################
#
# Host and port of the first MPD to control
# mpd:<player-id-1>.host=
# mpd:<player-id-1>.port=

# The password to authenticate against the MPD server (optional, can be null to
# indicate that no authentication is required)
# mpd:<player-id-1>.password=

# Host and port of the second MPD to control
# mpd:<player-id-2>.host=
# mpd:<player-id-2>.port=

# The password to authenticate against the MPD server (optional, can be null to
# indicate that no authentication is required)
# mpd:<player-id-2>.password=


################################ Mystrom Eco Power Binding ############################
#
# mystromecopower:userName=youremail
# mystromecopower:password=yourpassword


################################ VDR Binding ##########################################
#
# Host and port of the first VDR to control
# vdr:<vdr-id-1>.host=
# vdr:<vdr-id-1>.port=6419

# Host and port of the second VDR to control
# vdr:<vdr-id-2>.host=
# vdr:<vdr-id-2>.port=6419

################################ SNMP Binding #########################################
#
# Listening Port (optional, defaults to '162')
#snmp:port=

# The SNMP community to listen to (optional, defaults to 'public')
#snmp:community=

# The SNMP retry timeout (in milliseconds). Defaults to 1500.
# Sets the number of milliseconds between retries.
#snmp:timeout=

# The SNMP number of retries. Defaults to 0.
# Sets the number of retries before aborting the request.
#snmp:retries=

######################## Novelan (Siemens) Heatpump Binding ###########################
#
# IP address of the Novelan (Siemens) Heatpump to connect to (required)
#novelanheatpump:ip=

# port number of the Novelan (Siemens) Heatpump to connect to (optional, defaults to 8888)
#novelanheatpump:port=

# refresh interval in milliseconds (optional, defaults to 60000)
#novelanheatpump:refresh=

############################### Cups Binding ##########################################
#
# CupsServer IP address or Host name
#cups:host=

# CupsServer Port (optional, defaults to 631)
#cups:port=

# refresh interval in milliseconds (optional, defaults to 60000)
#cups:refresh=

############################ IHC / ELKO LS Binding ####################################
#
# Controller IP address
#ihc:ip=

# Username and password for Controller
#ihc:username=
#ihc:password=

# Timeout for controller communication
#ihc:timeout=5000

############################## Plugwise Binding #######################################
#
# "stick" is reserved plug wise id
#plugwise:stick.port=
# interval in ms to wait between messages sent on the ZigBee network
#plugwise:stick.interval=150

# "circleplus" is reserved plug wise id
#plugwise:circleplus.mac=

#plugwise:<plugwise-id-1>.mac=

############################### Modbus Binding ########################################
#
# sets refresh interval to Modbus polling service.
# Value in milliseconds (optional, defaults to 200)
#modbus:poll=

# host:port (mandatory)
#modbus:tcp.slave1.connection=

# The data type, can be "coil" "discrete" "holding" "input"
#modbus:tcp.slave1.type=

# The slave id (optional, defaults to '1')
#modbus:tcp.slave1.id=

# The slave start address (optional, defaults to '0')
#modbus:tcp.slave1.start=

# The number of data item to read
# (optional, defaults to '0' - but set it to something meaningful)
#modbus:tcp.slave1.length=

# Value type, required for combined registers (details: http://www.simplymodbus.ca/FAQ.htm#Types)
# Can be "bit", "int8", "uint8", "int16", "uint16", "int32", "uint32", "float32"
# (optional, defaults to 'uint16')
#modbus:tcp.slave1.valuetype=

############################### PLC Bus Binding #######################################
#
# PLCBus adapter serial port
#plcbus:port=

############################# Sonance Binding #######################################
#
# Sonance refresh rate in ms
# (defines, how often a values are updated when command are send or buttons are pressed)
#sonance:refresh=60000

################################# DMX Binding #########################################
#
# The combined connection String, e.g. 'localhost:9010' (optional, defaults to
# 'localhost:9010' or 'localhost:9020' depending on the choosen connection type)
#dmx:connection=

############################### Philips Hue Binding ###################################
#
# IP address of Hue Bridge (optional, default is auto-discovery)
#hue:ip=

# Default secret key for the pairing of the Philips Hue Bridge.
# It has to be between 10-40 (alphanumeric) characters
# This may be changed by the user for security reasons.
hue:secret=openHABRuntime

# Polling interval in msec to retrieve Philips bulb status.
# Other apps can change Hue status or a physical switch can turn on / off lamp status.
# If this happens the status of hue lamps within OpenHAB won't reflect the real status.
# Currently (September 2014) there is no push technology available, so the only option is
# to poll Philips bulbs to retrieve status and update items accordingly to reflect changes.
# Polling is enabled if refresh is specified, by commenting out "hue:refresh=10000" statement.
# Be aware that polling will consume resources, so a small refresh interval will increase cpu load.
# hue:refresh=10000

################################ RFXCOM Binding #######################################
#
# Serial port of RFXCOM interface
# Valid values are e.g. COM1 for Windows and /dev/ttyS0 or /dev/ttyUSB0 for Linux
#rfxcom:serialPort=

# Set mode command for controller (optional)
# E.g. rfxcom:setMode=0D000000035300000C2F00000000
#rfxcom:setMode=

############################## Pulseaudio Binding #####################################
#
# PulseaudioServer IP address
#pulseaudio:Main.host=

# PulseaudioServer Port (optional, defaults to 4712)
#pulseaudio:Main.port=

############################### Homematic Binding #####################################
#
# Hostname / IP address of the Homematic CCU
# homematic:host=

# The timeout in seconds for connections to a slower CCU (optional, default is 15)
# If you have a CCU1 with many devices, you may get a read time out exception.
# Increase this timeout to give the CCU1 more time to respond.
# homematic:host.timeout=

# Hostname / IP address for the callback server (optional, default is auto-discovery)
# This is normally the IP / hostname of the local host (but not "localhost" or "127.0.0.1").
# homematic:callback.host=

# Port number for the callback server. (optional, default is 9123)
# homematic:callback.port=

# The interval in seconds to check if the communication with the CCU is still alive.
# If no message receives from the CCU, the binding restarts. (optional, default is 300)
# homematic:alive.interval=

# The interval in seconds to reconnect to the Homematic server (optional, default is disabled)
# If you have no sensors which sends messages in regular intervals and/or you have low communication,
# the alive.interval may restart the connection to the Homematic server to often.
# The reconnect.interval disables the alive.interval and reconnects after a fixed period of time.
# Think in hours when configuring (one hour = 3600)
# homematic:reconnect.interval=

################################ Koubachi Binding #####################################
#
# refresh interval in milliseconds (optional, defaults to 900000ms, 15m)
#koubachi:refresh

# The URL of the Device list  (optional, defaults to
# 'https://api.koubachi.com/v2/user/smart_devices?user_credentials=%1$s&app_key=%2$s')
#koubachi:deviceurl

# The URL of the Plant list  (optional, defaults to
# 'https://api.koubachi.com/v2/plants?user_credentials=%1$s&app_key=%2$s')
#koubachi:planturl

# The URL for care actions  (optional, defaults to
# 'https://api.koubachi.com/v2/plants/%3$s/tasks?user_credentials=%1$s&app_key=%2$s')
#koubachi:tasksurl

# The single access token configured at http://labs.kpubachi.com
#koubachi:credentials

# The personal appKey configured at http://labs.koubachi.com
#koubachi:appkey

################################ Sonos Binding ########################################
#
#Add a line for each Sonos device you want to pre-define
#The format is <name>.udn=<RINCON UID>
#
#sonos:office.udn=RINCON_000XXXXXXXXX01400
#sonos:living.udn=RINCON_000YYYYYYYYY01400
#
#Interval, in milliseconds, to poll the Sonos devices for status variables
#sonos:pollingPeriod=1000

################################ SAMSUNG TV Binding ###################################
#
# Host of the first TV to control
# samsungtv:<TVid1>.host=
# Port of the TV to control (optional, defaults to 55000)
# samsungtv:<TVid1>.port=

# Host of the second TV to control
# samsungtv:<TVid2>.host=
# Port of the TV to control (optional, defaults to 55000)
# samsungtv:<TVid2>.port=

################################# Onkyo  Binding ######################################
#
# Host of the first Onkyo device to control
# onkyo:<OnkyoId1>.host=
# Port of the Onkyo to control (optional, defaults to 60128)
# onkyo:<OnkyoId1>.port=

# Host of the second Onkyo device to control
# onkyo:<OnkyoId2>.host=
# Port of the Onkyo to control (optional, defaults to 60128)
# onkyo:<OnkyoId2>.port=

################################ OpenSprinkler Binding ################################
#
# The type of OpenSprinkler connection to make (optional, defaults to 'gpio').
# There are two valid options:
#
# gpio: this mode is only applicable when running openHAB on a Raspberry Pi, which
#       is connected directly to an OpenSprinkler Pi. In this mode the communication
#       is directly over the GPIO pins of the Raspberry Pi
# http: this mode is applicable to both OpenSprinkler and OpenSprinkler Pi, as long as
#       they are running the interval program. Realistically though if you have an
#       OpenSprinkler Pi, it makes more sense to directly connect via gpio mode.
# openSprinkler:mode=

# If the http mode is used, you need to specify the url of the internal program,
# and the password to access it. By default the password is 'opendoor'.
# openSprinkler:httpUrl=http://localhost:8080/
# openSprinkler:httpPassword=opendoor

# The number of stations available. By default this is 8, but for each expansion board
# installed this number will can be incremented by 8 (optional, defaults to 8).
# openSprinkler:numberOfStations=

# The number of milliseconds between checks of the Open Sprinkler device
# (optional, defaults to 60 seconds).
# openSprinkler:refreshInterval=60000

############################ Epson Projector Binding ##################################
#
# Serial port or Host and port of the first Epson projector to control
# epsonprojector:<devId1>.serialPort=
# epsonprojector:<devId1>.host=
# Port of the Epson projector to control (optional, defaults to 60128)
# epsonprojector:<devId1>.port=

# Serial port or Host and port of the second Epson projector to control
# epsonprojector:<devId2>.serialPort=
# epsonprojector:<devId2>.host=
# Port of the Epson projector to control (optional, defaults to 60128)
# epsonprojector:<devId2>.port=

################################# Zehnder ComfoAir ####################################
#
# Serial port of the Zehnder ComfoAir to connect to
#comfoair:port=/dev/ttyS0

# refresh interval in milliseconds (optional, defaults to 60000)
#comfoair:refresh=

############################### EDS OWSever Binding ###################################
#
# Host of the first OWServer device to control
# owserver:<serverId1>.host=

# Host of the second OWServer device to control
# owserver:<serverId2>.host=

################################ digitalSTROM Binding #################################
#
# URI of the digitalSTROM server (dSS)
# digitalstrom:uri=https://dss.local:8080

# Connect timeout (defaults to 4000 ms)
#digitalstrom:connectTimeout=

# Connect timeout (defaults to 10000 ms)
#digitalstrom:readTimeout=

# to login without a user and password; loginToken must be enabled once
#digitalstrom:loginToken=

# to login with username and password; default user is dssadmin and default password
# is dssadmin if you have loginToken and username with password the loginToken will
# be prefered by default
#digitalstrom:user=
#digitalstrom:password=

##################################### xPL Binding #####################################
#
# The instance name of the xPL server on the xPL Network
#xpl:instance=somemachinename

############################ Squeezebox Action and Binding ############################
#
# Host (IP address) of your Logitech Media Server
#squeeze:server.host=

# Port of CLI interface of your Logitech Media Server (optional, defaults to 9090)
#squeeze:server.cliport=

# Webport interface of the your Logitech Media Server (optional, defaults to 9000)
#squeeze:server.webport=

# TTS URL to use for generating text-to-speech voice announcements
# the URL should contain one '%s' parameter which will be substituted
# with the text to be translated (new as of openHAB 1.8)
# (defaults to Google TTS service using the URL below)
#    http://translate.google.com/translate_tts?tl=en&ie=UTF-8&client=openhab&q=%s)
# (another TTS service is http://www.voicerss.org/api/ which requires an API key)
#    https://api.voicerss.org/?key=YOURAPIKEYHERE&hl=en-gb&src=%s
#squeeze:ttsurl=

# Maximum TTS sentence length - for example the Google TTS service only
# permits up to 100 chars - the Squeezebox speak action will break long
# strings into sentence chunks call the TTS service repeatedly
# (defaults to 100)
#squeeze:ttsmaxsentencelength=

# Id (MAC address) of your first Squeezebox.  MAC addresses of players are case-sensitive.
# Use small letters (a-f) if the address contains them. Example:
# squeeze:Kitchen.id=de:ad:be:ef:12:34
#squeeze:<boxId1>.id=

# Id (MAC address) of your nth Squeezebox
#squeeze:<boxIdN>.id=

################################### Milight Binding ###################################
#
# Host of the first Milight bridge to control
#milight:<MilightId1>.host=
# Port of the bridge to control (optional, defaults to 50000)
#milight:<MilightId1>.port=
#
# Host of the second Milight bridge to control
#milight:<MilightId2>.host=
# Port of the bridge to control (optional, defaults to 50000)
#milight:<MilightId2>.port=

############################### Systeminfo Binding ####################################
#
# Interval in milliseconds when to find new refresh candidates
# (optional, defaults to 1000)
#systeminfo:granularity=

# Data Storage Unit, where B=Bytes, K=kB, M=MB, T=TB (optional, defaults to M)
#systeminfo:units=

################################### PiFace Binding ####################################
#
# Watchdog polling interval (optional, defaults to 60000)
#piface:watchdog.interval=

# Host of the first Raspberry PI carrying a PiFace board
#piface:<piface-id1>.host=
# Port of the Piface listener of the first RasPi (optional, defaults to 15432)
#piface:<piface-id1>.listenerport=
# Port of the Piface monitor of the first RasPi (optional, defaults to 15433)
#piface:<piface-id1>.monitorport=
# Socket timeout when sending packets to the first RasPi (optional, defaults to 1000ms)
#piface:<piface-id1>.sockettimeout=
# Number of retry attempts before failing a packet for the first RasPi (optional, defaults to 3)
#piface:<piface-id1>.maxretries=


############################# Fritz AHA Binding #######################################
#
# refresh interval in milliseconds (optional, defaults to 10000)
#fritzaha:refresh=

# Binding supports multiple AHA hosts (e.g. FRITZ!Box, Fritz!Powerline 546E). Format is
# fritzaha:<hostID>.<option>=<value>, where hostID is up to user choice

# Host name of the first AHA host (e.g. fritz.box)
#fritzaha:<hostID1>.host=
# Port of the first AHA host (optional, defaults to protocol-specific default port)
#fritzaha:<hostID1>.port=
# Protocol to connect to web interface. Supports https and http.
# Use of https requires SSL certificate to be trusted by the JRE.
# (optional, defaults to http)
#fritzaha:<hostID1>.protocol=
# Username of the first AHA host. User must have HomeAuto permissions.
# (optional for local networks, required for remote access)
#fritzaha:<hostID1>.username=
# Password of the first AHA host's web interface.
# (optional, but required if password is set in host)
#fritzaha:<hostID1>.password=
# timeout for synchronous http-connections (optional, default 2000)
#fritzaha:<hostID1>.synctimeout=
# timeout for asynchronous http-connections (optional, default 4000)
#fritzaha:<hostID1>.asynctimeout=

############################## Tinkerforge  Binding ###################################
#
# IP addresses / Hostnames  of the hosts running the brickd (optional port
# separated by a colon, defaults to 4223)
# tinkerforge:hosts=

######################## NIBE HEAT PUMP Binding #######################################
#
# UDP port of the Heatpump Monitor (optional, defaults to 9999)
#nibeheatpump:udpPort=

# Switch on the Nibe HeatPump Simulator (for testing purpose only)
#nibeheatpump:simulate=true

################################ Z-Wave  Binding ######################################
#
# The Z-Wave controller port. Valid values are e.g. COM1 for Windows and /dev/ttyS0 or
# /dev/ttyUSB0 for Linux
#zwave:port=

# Z-Wave nightly heal time. This is the hour (eg 2AM) at which the automatic nightly
# network heal will be performed.
#zwave:healtime=2

################################ Nikobus Binding ######################################
#
# Serial Port connected to pc-link. Valid values are e.g. COM1 for Windows and /dev/ttyS0 or
# /dev/ttyUSB0 for Linux
#nikobus:serial.port=

# Directory path where the command cache file should be created.
# Optional. Defaults to the users' home directory.
#nikobus:cache.location=

# Perform a module status query every x seconds (optional, defaults to 600 (10 minutes)).
#nikobus:refresh=

################################# EnOcean Binding #####################################
#
# EnOcean USB adapter serial port
#enocean:serialPort=

################################# TCP - UDP Binding ###################################
#
# all parameters can be applied to both the TCP and UDP binding unless
# specified otherwise

# Port to listen for incoming connections
#tcp:port=25001

# Cron-like string to reconnect remote ends, e.g for unstable connection or remote ends
#tcp:reconnectcron=0 0 0 * * ?

# Interval between reconnection attempts when recovering from a communication error,
# in seconds
#tcp:retryinterval=5

# Queue data whilst recovering from a connection problem (TCP only)
#tcp:queue=true

# Maximum buffer size whilst reading incoming data
#tcp:buffersize=1024

# Share connections within the Item binding configurations
#tcp:itemsharedconnections=true

# Share connections between Item binding configurations
#tcp:bindingsharedconnections=true

# Share connections between inbound and outbound connections
#tcp:directionssharedconnections=false

# Allow masks in ip:port addressing, e.g. 192.168.0.1:* etc
#tcp:addressmask=true

# Pre-amble that will be put in front of data being sent
#tcp:preamble=

# Post-amble that will be appended to data being sent
#tcp:postamble=\r\n

# Perform all write/read (send/receive) operations in a blocking mode, e.g. the binding
# will wait for a reply from the remote end after data has been sent
#tcp:blocking=false

# timeout, in milliseconds, to wait for a reply when initiating a blocking write/read
#  operation
#tcp:timeout=3000

# Update the status of Items using the response received from the remote end (if the
# remote end sends replies to commands)
#tcp:updatewithresponse=true

# Timeout - or 'refresh interval', in milliseconds, of the worker thread
tcp:refreshinterval=250

# Timeout, in milliseconds, to wait when "Selecting" IO channels ready for communication
#tcp:selecttimeout=1000

# Used character set
#tcp:charset=ASCII

################################# Mqttitude Binding ###################################
#
# Mqttitude can track your presence in two ways;
#
#  1. Regions - by defining a region in your Mqttitude app (on your phone) you specify
#               a set of lat/lon coordinates, a geofence, and a name - by using this name
# 				in your item binding openHAB will listen for enter/leave events for this
#               region and thus allow you to track your presence in multiple locations
#  2. Home    - by defining the lat/lon of your home, along with a geofence radius (below),
#               the binding will listen for location publishes from the Mqttitude app and
#               manually calculate the distance from your 'home'
#
# Optional. The latitude/longitude coordinates of 'home'.
#mqttitude:home.lat=
#mqttitude:home.lon=

# Optional. The geofence radius.
#mqttitude:geofence=

############################### OpenPaths Binding #####################################
#
# The latitude/longitude coordinates of 'home'.
#openpaths:home.lat=
#openpaths:home.long=
#openpaths:home.geofence=

# You may define any number of additional locations. If no geofence is given
# for a location, the default geofence configuration below is used

# The latitude/longitude coordinates of 'work'.
#openpaths:work.lat=
#openpaths:work.long=
#openpaths:work.geofence=

# The latitude/longitude coordinates of 'anyplace'.
#openpaths:anyplace.lat=
#openpaths:anyplace.long=
#openpaths:anyplace.geofence=

# Interval in milliseconds to poll for user location (optional, defaults to 5mins).
#openpaths:refresh=

# Distance in metres a user must be from 'home' to be considered inside the
# geofence (optional, defaults to 100m).
#openpaths:geofence=

# OpenPaths access/secret keys for each user.
#openpaths:<name>.accesskey=<accesskey>
#openpaths:<name>.secretkey=<secretkey>

######################## Swegon ventilation Binding ###################################
#
# UDP port (optional, defaults to 9998)
#swegonventilation:udpPort=

# Switch on the Swegon Simulator (for testing purpose only)
#swegonventilation:simulate=true

############################### Pioneer AVR Binding ###################################
#
# Hostname/IP of the first Pioneer device to control
#pioneeravr:livingroom.host=

# Portnumber of the Pioneer device to control (optional, defaults to 23)
#pioneeravr:livingroom.port=

# Switch for disabling the connection check (optional, defaults to 1)
#pioneeravr:livingroom.checkconn=

################################ Heatmiser Binding ####################################
#
# Refresh interval in milliseconds (optional, defaults to 2000ms)
#heatmiser:refresh

# Set the heatmiser network address
#heatmiser:address=

# Set the port number for the Heatmiser interface
#heatmiser:port=

################################ NeoHub Binding #######################################
#
# Refresh interval in milliseconds (optional, defaults to 60000ms)
#neohub:refresh=60000

# Set the NeoHub network address
#neohub:hostname=

# Set the port number for the NeoHub interface (optional, defaults to 4242)
#neohub:port=4242

########################### Open Energy Monitor Binding ###############################
#
# UDP port of the Open Energy Monitor devices (optional, defaults to 9997)
#openenergymonitor:udpPort=9997

# For testing purposes
#openenergymonitor:simulate=true

################################ Netatmo Binding ######################################
#
# Refresh interval in milliseconds (optional, defaults to 300000)
#netatmo:refresh=

# The Netatmo client id (see http://dev.netatmo.com/dev/listapps)
#netatmo:clientid=

# The Netatmo client secret (see http://dev.netatmo.com/dev/listapps)
#netatmo:clientsecret=

# The Netatmo refresh token (see http://dev.netatmo.com/doc/authentication/usercred)
#netatmo:refreshtoken=

# The Netatmo unit system where M=Metric system - celsius/meters/millimeters,
#     US=US System - fahrenheit/feet/inches (optional, defaults to M)
#netatmo:unitsystem=

# The Netatmo pressure unit values: mbar, inHg, mmHg (optional, defaults to mbar)
#netatmo:pressureunit=

########################### HDanywhere Binding ########################################
#
# Optional, specify the number of input and output ports for a given HDanywhere matrix
#hdanywhere:192.168.0.88.ports=4

################################# Omnilink ############################################
#
# Enter the port (4369) host ip or name and the two crypto keys for your omni panel.
# The two keys may be found in the installer menu on a HAI keypad or touchscreen. Each
# key is 16 hex characters in pairs separated by colons (aa:bb:cc)
#
# Ff generateItems is set to true then the binding will print all known items and a
# sample sitemap to the log file (INFO).  Useful when setting up for the first time.
#
#omnilink:port=4369
#omnilink:host=panel.yourdomain.com
#omnilink:key1=00:AA:BB:CC:DD:EE:FF:11
#omnilink:key2=00:AA:BB:CC:DD:EE:FF:11
#omnilink:generateItems=true

####################### Freeswitch Action configuration ###############################
#
# Host or ip of your freeswitch server
#freeswitch:host=

# Port that your freeswitch server is listening for ESL connections on
# (optional, defaults to 8021)
#freeswitch:port=

# Password set for ESL connections
#freeswitch:password=

################################ MAX!Cube Binding #####################################
#
# MAX!Cube LAN gateway IP address (Optional, can be auto-discovered)
# maxcube:ip=192.168.0.222

# MAX!Cube port (Optional, default to 62910)
# maxcube:port=62910

# MAX!Cube refresh interval in ms (Optional, default to 10000)
# maxcube:refreshInterval=10000

# Max!Cube exclusive mode. (Optional, default to false)
# When true, the binding keeps the connection to the Cube open
# and polls more efficiently. No other application can use the Cube while the binding is running
# in exclusive mode, including Android and Desktop Max! Software.
# With this mode, the refreshInterval can easily set to 500 or 1000ms if you
# want the window contacts or eco button more responsive.
# maxcube:exclusive=false

# Max!Cube maximum requests per connection. (Optional, default to 1000)
# In exclusive mode, the binding will open the connection to the Cube and polls with
# refreshInterval maxRequestsPerConnection times. When maxRequestsPerConnection is reached
# it will disconnect and reconnect. This may work around issues with long going connections
# like slow reaction on events.
# When set to 0, the binding will keep the connection open as long as possible.
# maxcube:maxRequestsPerConnection=1000

################################# IRtrans Binding #############################################
#
# Timeout - or 'refresh interval', in milliseconds, of the worker thread
# (mandatory parameter to enable the IRtrans binding)
#irtrans:refreshinterval=250

# Timeout, in milliseconds, to wait for a reply when sending a command (default is 1000)
#irtrans:timeout=3000

# The IRtrans binding also takes all the configuration parameters of the TCP/UDP binding
# except that some of these items, for internal purposes, will be overruled by the binding itself

############################### Daikin Binding ########################################
#
# Require a KKRP01A Online Controller and a Daikin heat pump.

# Refresh interval in milliseconds (optional, defaults to 60000)
#daikin:refresh=

# Daikin Online Controller - host address and optional username/password
# NOTE: currently the username/password are ignored - you must configure
#       the KKRP01A with no security - i.e. empty password for all logins
#daikin:<id>.host=
#daikin:<id>.username=
#daikin:<id>.password=

################################# Astro Binding #######################################
#
# The latitude
#astro:latitude=

# The longitude
#astro:longitude=

# Refresh interval for azimuth and elevation calculation in seconds
# (optional, defaults to disabled)
#astro:interval=

############################### Insteon PLM Binding ###################################
#
# The insteon PLM controller port, one for each modem or hub.
# You can have multiple ports, but that has never been tested, use at your own peril.
#
# examples of valid port configurations for serial or usb modems:
#
# Linux, with serial port symlinked to /dev/insteon:
# insteonplm:port_0=/dev/insteon
#
# Linux, with plain old serial modem:
# insteonplm:port_0=/dev/ttyS0
#
# Linux, with usb based PLM modem:
# insteonplm:port_0=/dev/ttyUSB0
#
# Windows, with serial/usb modem on COM1:
# insteonplm:port_0=COM1
#
# to connect to an Insteon Hub2 (the 2014 version) on port 25105 with
# a poll interval of 1000ms = 1sec, use the following line. Use the login
# and password that is printed on the label on the bottom of the hub,
# NOT the Insteon online login and password!
#
# insteonplm:port_0=/hub2/my_user_name:my_password@myinsteonhub.mydomain:25105,poll_time=1000

#
# to connect to the raw tcp feed on an older Insteon Hub (pre 2014 version) on port 9761
#
# insteonplm:port_0=/hub/localhost:9761


# Poll interval (optional, in milliseconds, defaults to 300000).
# Poll too often and you will overload the insteon network, leading to sluggish
# or no response when trying to send messages to devices. Poll too rarely and it'll
# take a long time to establish the correct state of all devices.
# The default poll interval of 300s has been tested and found to be a good
# compromise in a configuration of about 110 switches/dimmers.
#
#insteonplm:poll_interval=300000

#
# If the modem database download times out prematurely (while the download is
# still making progress), bump this parameter. Timeout is in milliseconds, default is 120000.
# You should not have to adjust this parameter. Please post on the openhab forum if you do
# have to bump it.
#
# insteonplm:modem_db_retry_timeout=120000



# optional file with additional device types. The syntax of
# the file is identical to the device_types.xml file in the
# source tree. Please remember to post successfully added
# device types to the openhab group so the developers
# can include them into the device_types.xml file!
#
#insteonplm:more_devices=/path_to_file/more_devices.xml

# optional file with additional feature templates, like
# in the device_features.xml file in the source tree.
#
#insteonplm:more_features=/path_to_file/more_features.xml


################################ K8055 Binding ########################################
#
# refresh interval in milliseconds (optional, defaults to 1000ms)
#k8055:refresh=1000

# Board Number.  Defaults to 0
#k8055:boardno=0

############################## Withings Binding #######################################
#
# Data refresh interval in ms (optional, defaults to 60000)
#withings:refresh=


#############################  IEC 620562-21 Meter Binding ############################
#
# the serial port to use for connecting to the metering device e.g. COM1 for Windows
# and /dev/ttyS0 or /dev/ttyUSB0 for Linux
#iec6205621meter:<meter-id1>.serialPort=/dev/ttyS0

# Delay of baud rate change in ms. Default is 0. USB to serial converters often
# require a delay of up to 250ms default is 0ms
#iec6205621meter:<meter-id1>.baudRateChangeDelay=

# Enable handling of echos caused by some optical tranceivers
# default is true
#iec6205621meter:<meter-id1>.echoHandling=true

# Perform a module status query every x miliseconds (optional, defaults to 60000)
#iec6205621meter:refresh=

################################### GPIO Binding ######################################

# Optional directory path where "sysfs" pseudo file system is mounted, when isn't
# specified it will be determined automatically if "procfs" is mounted
#gpio:sysfs=/sys

# Optional time interval in miliseconds when pin interrupts are ignored to
# prevent bounce effect, mainly on buttons. Global option for all pins, can be
# overwritten per pin in item configuration. Default value if omitted: 0
#gpio:debounce=10

# Boolean controlling whether already exported pin should be forcibly taken under
# control of openHAB. Usefull after unclean shutdown. May cause serios issue if
# other software/system is also controlling GPIO and there is a configuration
# mistake for pin name/number. Default value if omitted: false.
#gpio:force=true

############################## Waterkotte EcoTouch Binding ############################
#
# Data refresh interval in ms (optional, defaults to 60000)
#ecotouch:refresh=

# The IP address of the Waterkotte EcoTouch display unit (required)
#ecotouch:ip=

# These are the login credentials (required).
# There is no way to change them at the EcoTouch display unit (as far as I know).
#ecotouch:username=admin
#ecotouch:password=wtkadmin

############################# Yamaha Receiver Binding #################################
#
# The IP address of the Yamaha Receiver (required)
#yamahareceiver:<id>.host=

# The refresh interval in ms (optional, defaults to 60000)
#yamahareceiver:refresh=60000

############################## alarmdecoder binding ###################################
#
# use this line to reach an IP-enabled alarmdecoder (ad2pi) via tcp:
#alarmdecoder:connect=tcp:ad2pihostname.mydomain.com:port

# for serial port access use a line like this:
#alarmdecoder:connect=serial:/dev/ttyUSB0
# or this to override the default speed:
#alarmdecoder:connect=serial@9600:/dev/ttyUSB0

# time (in milliseconds) between attempts to reconnect to the alarmdecoder
# in case the connection goes down
#alarmdecoder:reconnect=10000

# set this to true if you want to send commands to the alarm panel as well
#alarmdecoder:send_commands_and_compromise_security=false

################################# Davis Binding #######################################
#
# The Davis weather station port. Valid values are e.g. COM1 for Windows and
# /dev/ttyS0 or /dev/ttyUSB0 for Linux.
#
#davis:port=COM7

# refresh value (optional, in milliseconds, defaults to 10000)
#davis:refresh=10000

############################# BenqProjector Binding  ##################################

# mode controls how the projector can be reached. 'serial' is for a directly
# connected RS232 serial interface while 'network' is for using a TCP/IP to
# serial converter
#benqprojector:mode=network

# For mode=network, define the Serial to Ethernet device location
#benqprojector:deviceId=<hostname>:<port>

# For mode=serial, define the serial device (e.g. /dev/ttyUSB0) and speed
# (defaults to 57600 bps)
#benqprojector:deviceId=<device>:<speed>

# Define polling interval in milliseconds
#benqprojector:refresh=15000


############################### Libelium eHealth ######################################
#
# Configures the serial port where the eHealth kit is attached to
# (e.g. '/dev/tty.usbmodem1411')
#ehealth:serialPort=

########################## Anel NET-PwrCtrl Binding ###################################
#
# <name> must a an identifier that is also used for the item bindings.
# Example configuration: anel:anel1.host=net-control
# Example item binding: Switch f1 { anel="anel1:F1" }

# IP or network address (optional but recommended, defaults to 'net-control')
#anel:<name>.host=anel1

# UDP receive port (optional, defaults to 77)
#anel:<name>.udpReceivePort=7777

# UDP send port (optional, defaults to 75)
#anel:<name>.udpSendPort=7775

# User name (optional, defaults to 'user7')
#anel:<name>.user=user1

# Password (optional, defaults to 'anel')
#anel:<name>.password=anel

# Global refresh interval in ms (optional, defaults to 60000 = 1min, disable with '0')
#anel:refresh=60

# Cache the state for n minutes so only changes are posted (optional, defaults to 0 = disabled)
# Example: if period is 60, once per hour all states are posted to the event bus;
#          changes are always and immediately posted to the event bus.
# The recommended value is 60 minutes.
#anel:cachePeriod=60


################################## LgTV  Binding ######################################
#
# The ip address of the lgtv
#lgtv:<lgtvId1>.host=

# The TCP port address to use
#lgtv:<lgtvId1>.port=

# The the pairkey / if it's wrong the device shows the right pairkey
# at every connection attempt
#lgtv:<lgtvId1>.pairkey=

# The TCP port address of the openhab system to receive lgtv status messages
# (only first occurance is used for all tvs)
#lgtv:<lgtvId1>.serverport=

# The location to put xml files with the information of availiable
# channels and apps (optional)
#lgtv:<lgtvId1>.xmldatafiles=./

# The check alive interval (optional, defaults to 60secs)
#lgtv:<lgtvId1>.checkalive=

############################### Enigma2 Binding #######################################
#
# Refresh interval for state updates in milliseconds (configured once, valid
# for each device), e.g.
#enigma2:refresh=10000
#
# The following configs must be configured separate for each device, where
# <name> ist a placeholder for the device identifier
#
# IP or network address of the Enigma2 device, e.g.
#enigma2:<name>:hostname=192.168.178.25
#enigma2:<name>:hostname=vusolo2
#
# User name for the web interface of the Enigma2 device, e.g.
#enigma2:<name>:username=
#
# Password for the web interface of the Enigma2 device, e.g.
#enigma2:<name>:password=
#

############################### pilight Binding #######################################
#
# pilight:<instance name>.<parameter>=<value>
#

# IP address of the pilight daemon
#pilight:kaku.host=192.168.1.22

# Port of the pilight daemon
#pilight:kaku.port=5000

# Optional delay (in millisecond) between consecutive commands.
# Recommended value without band pass filter: 1000
# Recommended value with band pass filter: somewhere between 200-500
#pilight:kaku.delay=1000

################################### Weather Binding ###################################
#
# The apikey values for the different weather providers
# Note: Hamweather requires two apikeys: client_id=apikey, client_secret=apikey2
#weather:apikey.ForecastIo=
#weather:apikey.OpenWeatherMap=
#weather:apikey.WorldWeatherOnline=
#weather:apikey.Wunderground=
#weather:apikey.Hamweather=
#weather:apikey2.Hamweather=

# location configuration, you can specify multiple locations
# Note: latitude and longitude are NOT required for Yahoo
#       woeid is ONLY required for Yahoo
#weather:location.<locationId1>.name=
#weather:location.<locationId1>.latitude=
#weather:location.<locationId1>.longitude=
#weather:location.<locationId1>.woeid=
#weather:location.<locationId1>.provider=
#weather:location.<locationId1>.language=
#weather:location.<locationId1>.updateInterval=

#weather:location.<locationId2>.name=
#weather:location.<locationId2>.latitude=
#weather:location.<locationId2>.longitude=
#weather:location.<locationId2>.woeid=
#weather:location.<locationId2>.provider=
#weather:location.<locationId2>.language=
#weather:location.<locationId2>.updateInterval=

################################### Zibase Binding #####################################
#
# The IP Address of the Zibase (required)
#zibase:ip=

# The IP Address sent to Zibase to register as listener (optional, defaults 127.0.0.1)
#zibase:listenerHost=127.0.0.1

# The TCP Port to use for data exchange with the Zibase (optional, defaults 9876)
#zibase:listenerPort=9876

# The refresh interval in ms for sensors.xml reading (optional, defaults to 60000)
#zibase:refresh=6000

############################## BTicino Binding ########################################
#
# OpenWeb gateway IP address / Hostname -> bticino:default.host=x.x.x.x OR hostname
# OpenWeb gateway Port (optional, defaults to 20000) -> bticino:default.port=z (20000)
# Interface with name aaa bticino:aaa.host=x.x.x.x OR hostname
# OpenWeb gateway Port (optional, defaults to 20000) bticino:aaa.port=z (20000)

# Host and port of the default OpenWeb bticino IF
# OpenWeb gateway IP address / Hostname
#bticino:default.host=

# OpenWeb gateway Port (optional, defaults to 20000)^M
#bticino:default.port=

# OpenWeb bus status rescan interval (optional, defaults to 120 seconds)
#bticino:default.rescan_secs=

############################### NetworkUpsTools Binding ###############################
#
# networkupstools:<instance name>.<parameter>=<value>
#

# Refresh interval for state updates in milliseconds (optional)
#networkupstools:refresh=60000

# UPS device name
#networkupstools:ups1.device=ups

# UPS server hostname (optional)
#networkupstools:ups1.host=localhost

# UPS server port (optional)
#networkupstools:ups1.port=3493

# UPS server login (optional)
#networkupstools:ups1.login=

# UPS server pass (optional)
#networkupstools:ups1.pass=

############################### Autelis Pool Control Binding ##########################
#
# Host (name or ip) to connect to
# optional port (default 80)
# optional username and password (no default)
# optional refresh rate in millis (default 5000)
#
#autelis:refresh=5000
#autelis:host=poolcontrol
#autelis:port=80
#autelis:username=admin
#autelis:password=admin

############################## Nest binding ###########################################
#
# Data refresh interval in ms (optional, defaults to 60000)
#nest:refresh=

# HTTP request timeout in ms (optional, defaults to 10000)
#nest:timeout=

# the Nest Client ID needed to use the API, must be supplied
#nest:client_id=

# the Nest Client Secret needed to use the API, must be supplied
#nest:client_secret=

# the PIN code that Nest presented when you authorized the above client, must be supplied
#nest:pin_code=

############################### Satel Binding #########################################
#
# Satel ETHM-1 module hostname or IP.
# Leave this commented out for INT-RS module.
#satel:host=

# ETHM-1 port to use (optional, defaults to 7094), if host setting is not empty.
# INT-RS port to use, if host setting is empty.
#satel:port=

# timeout value for both ETHM-1 and INT-RS (optional, in milliseconds, defaults to 5000)
#satel:timeout=

# refresh value (optional, in milliseconds, defaults to 10000)
#satel:refresh=

# user code for Integra control (optional, if empty binding works in read-only mode)
#satel:user_code=

# encryption key (optional, if empty communication is not encrypted)
#satel:encryption_key=

############################## eBus Binding ###########################################
#

# Serial port of eBus interface
# Valid values are e.g. COM1 for Windows and /dev/ttyS0 or /dev/ttyUSB0 for Linux
#ebus:serialPort=COM2

# TCP Hostname and Port
# Warning: Only use ebus.hostname or ebus.serialPort
#ebus:hostname=myhostname
#ebus:port=5000

# Custom parser configuration file
# This example tries to load a configuration ${openhab_home}/configurations/ebus-config.json
#ebus:parserUrl=platform:/base/../configurations/ebus-config.json

# Load different parser, currently supported
# >> common - All telegrams defined by eBus interest group
# >> wolf - All telegrams specified by Wolf/Kromschröder
# >> vaillant - All telegrams specified by Vaillant
# >> testing -  All unknown or test telegrams
# >> custom - Use configuration defined by ebus:parserUrl
# default uses common and all vendor specified telegrams
#ebus:parsers=common,wolf,testing,custom

# Set the sender id of this binding, default is "FF"
#ebus:senderId=FF

############################### Plex Binding ##########################################
#
# IP address of the Plex server
#plex:host=192.168.1.15

# Optional, port that the Plex server is running on. Default = 32400
#plex:port=32400

# Refresh interval in ms. Default = 5000.
#plex:refresh=5000

 # If you're using Plex Home you need to supply the username and password of your
 # Plex account here. If you don't want to enter your credentials you can also
 # directly set your account token below instead.
#plex:username=Plex username

 # Plex password
#plex:password=Plex password

# Plex account token, use instead of username/password when using Plex Home.
#plex:token=abcdefghijklmnopqrst

############################### Denon Binding #########################################
#
# denon:<instance>.<property>=value

# IP adress of the Denon receiver instance
#denon:avr2000.host=192.168.1.70

# Optional, set connection method for receiving updates. Can be http or telnet.
# Denon receivers only support one concurrent telnet connection, so use http if
# you have any other app using the telnet connection. Default = telnet
#denon:avr2000.update=telnet

# Optional, this sets the refresh interval (in milliseconds) for all instances
# if you're using the http connection method. Default = 5000
#denon:refresh=5000

############################ Frontier Silicon Radio Binding ###########################
#
# Hostname/IP of the radio to control
#frontiersiliconradio:radio.host=192.168.0.100

# PIN access code of the radio (default: 1234)
#frontiersiliconradio:radio.pin=1234

# Portnumber of the radio to control (optional, defaults to 80)
#frontiersiliconradio:radio.port=80

# The number of milliseconds between checks of the radio
# (optional, defaults to 60 seconds).
#frontiersiliconradio:refreshInterval=60000

# Cache the state for n minutes so only changes are posted (optional, defaults to 0 = disabled)
# Example: if period is 60, once per hour all states are posted to the event bus;
#          changes are always and immediately posted to the event bus.
# The recommended value is 60 minutes.
#frontiersiliconradio:cachePeriod=60

########################### Sager Weather Caster Binding ##############################
#
# Latitude of the observed values
#sagercaster:latitude=

# The name of the persistence service to use (optional, defaults persistence:default)
#sagercaster:persistence=

################################# Primare Binding #####################################
#
# Add a set of parameters for each Primare device you want to control
# primare:<name>.<parameter>=<value>

# Model of the first Primare device to control (SP31|SP31.7|SPA20|SPA21)
# primare:myspa20.model=SPA20

# If connected directly to serial port:
# Serial port (or pty) of the first Primare device to control
# primare:myspa20.serial=/dev/ttyAMA0

# If connected to TCP-serial converter (such as a linux box running socat):
# Host of the first Primare device to control
# primare:myspa20.host=10.0.0.1
# Port of the first Primare to control
# primare:myspa20.port=8001

################################# LightwaveRf Binding #################################
#
# The IP Address of the LightwaveRf Wifi Link you can use the broadcast address (required)
#lightwaverf:ip=255.255.255.255

# The port to monitor for messages you shouldn't need to change this
#lightwaverf:receiveport=9760

# The port to send messages on, it will also be monitored for incoming messages
# you shouldn't need to change this
#lightwaverf:sendport=9761

# For a new computer you will need to register it with the wifi link to be allowed to
# send messages setting this to true we will send a registration message on startup.
# You will need to confirm registration on the wifi link. There is no harm leaving
# this as true but you can set to false once you have registerd for the first time.
#lightwaverf:registeronstartup=true

# Delay between sending messages in ms to avoid swapming Wifi Link
#lightwaverf:senddelay=2000

# Timeout for OK Messages in ms, we will retry messages we don't receive an ok for in
# the timeout
#lightwaverf:okTimeout=1000

################################ Souliss Binding ######################################
#
# For ITEM defination in file .item like {souliss=<Typical>:<nodeID>:<slot>:[<bit>]}

#souliss:IP_LAN=192.168.1.105
#souliss:USER_INDEX=71
#souliss:NODE_INDEX=134

# SERVERPORT - Leave empty for casual port
#souliss:SERVERPORT=

# Time in mills - min 50
#souliss:REFRESH_DBSTRUCT_TIME=600000
#souliss:REFRESH_SUBSCRIPTION_TIME=120000
#souliss:REFRESH_HEALTY_TIME=60000
#souliss:REFRESH_MONITOR_TIME=500
#souliss:SEND_DELAY=1500
#souliss:SEND_MIN_DELAY=100
#souliss:SECURE_SEND_TIMEOUT_TO_REQUEUE=5000
#souliss:SECURE_SEND_TIMEOUT_TO_REMOVE_PACKET=30000

################################ Ecobee Binding #######################################
#
# the private API key issued be Ecobee to use the API (required, replace with your own)
#ecobee:appkey=9T4huoUXlT5b5qNpEJvM5sqTMgaNCFoV

# the application scope used when authorizing the binding
# choices are smartWrite,smartRead, or ems, or multiple (required, comma-separated, no spaces)
#ecobee:scope=smartWrite

# Rate at which to check if poll is to run, in ms (optional, defaults to 5000)
#ecobee:granularity=5000

# Data refresh interval in ms (optional, defaults to 180000)
#ecobee:refresh=180000

# Time in ms to wait after successful update, command or action before refresh (optional, defaults to 6000)
#ecobee:quickpoll=6000

# Time in ms to allow an API request to complete (optional, defaults to 20000)
#ecobee:timeout=20000

# the temperature scale to use when sending or receiving temperatures
# optional, defaults to Fahrenheit (F)
#ecobee:tempscale=C

################################ Panasonic TV Binding #######################################
#
# IP address of a Panasonic TV instance
# panasonictv:<id>=

############################### IPX800 Binding ###################################
#
# The ipx800 must be configured with 'Send data on status changed' activated in M2M > TCP client
# Please setup here ip address, port and extensions.
# See documentation to know how to setup items

# Ip or hostname of ipx800
#ipx800:<name>.host=<ip or hostname>

# Tcp client connection port (optional, default to 9870)
#ipx800:<name>.port=

# Extension setup
# This step is needed to declare extensions and give them alias
# Two types of extensions are supported : x880, x400

# Ex: this declare a x880 extension connected to ipx <name> on the first address using alias <alias>
#ipx800:<name>.x880.1=<alias>
# Ex: this declare a x400 extension connected to ipx <name> on the second address using alias <alias>
#ipx800:<name>.x400.2=<alias>

############################## TACmi Binding ##############################
#
# Refresh interval in milliseconds (optional, defaults to 1000)
# This value can be set very small as it is only the value after which the binding restarts
# the receiver for new messages. The receiver itself will then wait for up to 10 seconds
# for new messages to arrive
# tacmi:refresh=10
# IP or hostname of the CMI device
# tacmi:cmiAddress=<ip>

############################## RWE Smarthome Binding ##############################
#
# Hostname / IP address of the RWE Smarthome server
# rwesmarthome:host=

# Username / password of the RWE Smarthome server
# rwesmarthome:username=
# rwesmarthome:password=

# The interval in milliseconds to poll the RWE Smarthome server for changes. (optional, default is 2000)
# Too low values may cause errors, too high values will lead to longer delays, until updates are seen
# in OpenHAB. Should not be smaller than 1000.
# rwesmarthome:poll.interval=2000

# The interval in seconds to check if the communication with the RWE Smarthome server is still alive.
# If no message receives from the RWE Smarthome server, the binding restarts. (optional, default is 300)
# rwesmarthome:alive.interval=300

# The interval in seconds to wait after the binding configuration has changed before the device states
# will be reloaded from the RWE SHC. (optional, default is 15)
# rwesmarthome:binding.changed.interval=15

############################## DSMR Binding ################################
#
# Port of the DSMR port (mandatory, e.g. /dev/ttyUSB0)
#dsmr:port=/dev/ttyUSB1
# Configuration of additional meters (channel 0 is used for the main electricity meter)
#dsmr:gas.channel=1
#dsmr:water.channel=2
#dsmr:heating.channel=3
#dsmr:cooling.channel=4
#dsmr:generic.channel=5
#dsmr:slaveelectricity.channel=6

################################ Sapp Binding ########################################
#
## polling refresh time in msec, default 100ms
#sapp:refresh=100

## pnmas list
#sapp:pnmas.ids=home,office

## pnmas definitions (ip and port). Only the pnmas listed in 'sapp:pnmas.ids' are used
#sapp:pnmas.home.ip=192.168.50.40
#sapp:pnmas.home.port=7001
#sapp:pnmas.office.ip=192.168.1.37
#sapp:pnmas.office.port=4001

######################## Telegram Action configuration ####################################
#
# Telegram bots data
#
# telegram:bots=bot1,bot2
# telegram:bot1.chatId=22334455
# telegram:bot1.token=xxxxxx
# telegram:bot2.chatId=654321
# telegram:bot2.token=yyyyyyyyyyy

############################ SiteWhere Persistence Service #############################
#
# Unique hardware id of device that will receive events.
# sitewhere:defaultHardwareId=123-OPENHAB-777908324
#
# Device specification token used if device is not already registered.
# sitewhere:specificationToken=5a95f3f2-96f0-47f9-b98d-f5c081d01948
#
# MQTT broker hostname SiteWhere is listening to.
# sitewhere:mqttHost=localhost
#
# MQTT broker port SiteWhere is listening to.
# sitewhere:mqttPort=1883

################################ UCProjects.eu Relay Board Binding ###################################
#
# Port and baud rate (optional, defaults to 57600) for every device
# ucprelayboard:board.one.port=/dev/tyUSB0
# ucprelayboard:board.<name>.baud=
#
# Refresh of relay board state interval in miliseconds (optional, defaults to 60000)
# ucprelayboard:refresh=

############################## Chamberlain MyQ Binding ##############################
#
# Data refresh interval in ms (optional, defaults to 60000)
# myq:refresh=60000

# Timeout for HTTP requests (optional, defaults to 5000)
# myq:timeout=5000

# Chamberlain MyQ Username and Password
# myq:username=
# myq:password=

# Application ID for the MyQ API (optional, only recommended if existing id ceases to work)
# myq:appId=JVM/G9Nwih5BwKgNCjLxiFUQxQijAebyyg8QUHr7JOrP+tuPb8iHfRHKwTmDzHOu

################################ Stiebel Heatpump Binding #############################
#
# the serial port to use for connecting to the metering device e.g. COM1 for Windows and /dev/ttyS0 or
# /dev/ttyUSB0 for Linux
#stiebelheatpump:serialPort=

# Baudrate of the serial interface. Default is 9600.
# default is 9600
#stiebelheatpump:baudRate=

# timeout on serial interface when establish connection
# default is 5
#stiebelheatpump:serialTimeout=

# Perform a module status query every x miliseconds (optional, defaults to 60000 (10 minutes)).
#stiebelheatpump:refresh=

# version string of the heatpump
#stiebelheatpump:version=2.06

############################### Sallegra Binding ####################################
#
# IP address or hostname for the module
#sallegra:livingroom.hostname=192.168.0.52
#sallegra:bedroom.hostname=192.168.0.54

# Password for the module
#sallegra:livingroom.password=admin
#sallegra:bedroom.password=admin
'''

OPENHAB_ITEM = 'String /sensor_id/ "/sensor_id/: [%s]" {mqtt="<[mqttIn:/sensor_id/:state:default], >[mqttOut:/sensor_id/:state:*:EXEC(/openhab/configurations/get_timestamp.sh ${state} ${itemName})]"}\n'

ONEM2M_ITEM = "[{'item_name': 'test', 'topic': 'test', 'item_type': '1'}]"

ONEM2M_CONFIG = {"clientId": "OneM2M_1", "inbound_broker_addr": "tcp://mqtt-service:1883",
                 "outbound_broker_addr": "tcp://188.166.238.158:30146", "qos": "0"}

OPENHAB_ITEM_KEY = 'demo.items'

OPENHAB_CONFIG_KEY = 'openhab.cfg'

ONEM2M_CONFIG_KEY = 'config.cfg'

ONEM2M_ITEM_KEY = 'items.cfg'

"""
{"kind":"ConfigMap","apiVersion":"v1","metadata":{"name":"onem2m-items-openhab-kube-system-test-16","namespace":"kube-system","selfLink":"/api/v1/namespaces/kube-system/configmaps/onem2m-items-openhab-kube-system-test-16","uid":"b0891c6e-2804-11e7-a3fd-7eb92be1eeb0","resourceVersion":"1104564","creationTimestamp":"2017-04-23T09:10:26Z"},"data":{"demo.items":"item"}}

Deploy config
{"kind":"ConfigMap","apiVersion":"v1","metadata":{"name":"openhab-cfg-openhab-kube-system-test-16","namespace":"kube-system","selfLink":"/api/v1/namespaces/kube-system/configmaps/openhab-cfg-openhab-kube-system-test-16","uid":"b09d8c97-2804-11e7-a3fd-7eb92be1eeb0","resourceVersion":"1104565","creationTimestamp":"2017-04-23T09:10:26Z"},"data":{"openhab.cfg":"config"}}

{"kind":"ReplicationController","apiVersion":"v1","metadata":{"name":"openhab-kube-system-test-16","namespace":"kube-system","selfLink":"/api/v1/namespaces/kube-system/replicationcontrollers/openhab-kube-system-test-16","uid":"b0b26487-2804-11e7-a3fd-7eb92be1eeb0","resourceVersion":"1104567","generation":1,"creationTimestamp":"2017-04-23T09:10:26Z","labels":{"app":"openhab-kube-system-test-16","description":"test","label":"test","namespace":"kube-system","regex":"test","version":"test"}},"spec":{"replicas":1,"selector":{"app":"openhab-kube-system-test-16"},"template":{"metadata":{"name":"openhab-kube-system-test-16","creationTimestamp":null,"labels":{"app":"openhab-kube-system-test-16","description":"test","label":"test","namespace":"kube-system","regex":"test","version":"test"}},"spec":{"volumes":[{"name":"openhab-cfg","configMap":{"name":"openhab-cfg-openhab-kube-system-test-16","items":[{"key":"openhab.cfg","path":"openhab.cfg"}],"defaultMode":420}},{"name":"openhab-items","configMap":{"name":"onem2m-items-openhab-kube-system-test-16","items":[{"key":"demo.items","path":"demo.items"}],"defaultMode":420}}],"containers":[{"name":"openhab-kube-system-test-16","image":"huanphan/openhab:semi-final-5","ports":[{"containerPort":8080,"protocol":"TCP"}],"resources":{},"volumeMounts":[{"name":"openhab-cfg","mountPath":"/openhab/configurations/openhab.cfg","subPath":"openhab.cfg"},{"name":"openhab-items","mountPath":"/openhab/configurations/items","subPath":"demo.items"}],"terminationMessagePath":"/dev/termination-log","imagePullPolicy":"IfNotPresent"}],"restartPolicy":"Always","terminationGracePeriodSeconds":30,"dnsPolicy":"ClusterFirst","securityContext":{}}}},"status":{"replicas":0}}

"""

############################### Sensor ##########################################
SENSOR_ITEM = {
        'Weather-Temperature-Sensor': 'name=Weather-Temperature-Sensor-{id},topic={id},frequent={freq},type=Diode,unit=Temperature:Celsius,label=task:collect_temperature,namespace={namespace},version={version},resoure_type=sensor',
        'Body-Temperature-Sensor': 'name=Body-Temperature-Sensor-{id},topic={id},frequent={freq},type=IC,unit=Temperature:Fahrenheit,label=task:collect_temperature,namespace={namespace},version={version},resoure_type=sensor',
        'SONY-Light-Sensor-V1': 'name=SONY-Light-Sensor-V1-{id},topic={id},frequent={freq},type=IC,unit=LightMeter:ISO,label=task:light_meter,namespace={namespace},version={version},resoure_type=sensor',
        'ATA-Light-Sensor-V2': 'name=ATA-Light-Sensor-V2-{id},topic={id},frequent={freq},type=Semiconductor,unit=LightMeter:ISO,label=task:light_meter,namespace={namespace},version={version},resoure_type=sensor',
        'SENSYS-Atmosphere-Sensor': 'name=SENSYS-Atmosphere-Sensor- id},topic={id},frequent={freq},type=IC,unit=Pressure:PSI,label=task:pressure_warning,namespace={namespace},version={version},resoure_type=sensor'
}
SENSOR_ITEM_KEY = 'items.cfg'
SENSOR_CONFIG = """ip_broker=mqtt-service
port_broker=1883
broker_client_name=/broker_client_name/
increase_freq=False
increase_instance=True
test_time=10800
qos=0
"""
SENSOR_CONFIG_KEY = 'config.cfg'

REPLICATION_RESOURCE = 'replicationcontrollers'
CONFIG_MAP_RESOURCE = 'configmaps'

POD_RESOURCE = 'pods'