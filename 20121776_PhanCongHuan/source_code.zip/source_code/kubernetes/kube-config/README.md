# Instruction
1. Create configmap first
  ```
  kubectl create configmap [name] --from-file [file_path] --namespace [namespace]
  ```

2. Create deployment
  ```
  kubectl create -f [file_path] 
  ```
