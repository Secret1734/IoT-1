#--------- Turn on services + components
# start heapster
# start mqtt
# start co-ordinator
# start platform-manager
# start sensor-simulator
# start data-collector